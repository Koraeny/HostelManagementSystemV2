INSERT INTO Student (student_id, name, age, gender, contact, course)
VALUES (7, 'Dave Cole', 21, 'Male', '1234567890', 'Computer Science');



SELECT * FROM Student WHERE student_id = 7;
