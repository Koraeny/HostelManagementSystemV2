SELECT 
    name AS AdminName
FROM 
    Administrator
WHERE 
    username = 'admin1' AND password = 'password123';
